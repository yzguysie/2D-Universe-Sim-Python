import pygame
pygame.init()

class button:
    def __init__(self, surface, x, y, width, height, text, color, border_color, text_color):
        self.surface = surface
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
        self.border_color = border_color
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.text_color = text_color
        self.text_size = int(width/len(text)*1.5)
        self.font = pygame.font.SysFont('Times New Roman', self.text_size)
        self.being_clicked = False
        self.enabled = True

    def draw(self):
        if self.enabled:
            pygame.draw.rect(self.surface, self.color, self.rect)
            pygame.draw.rect(self.surface, self.border_color, self.rect, int(min(self.width, self.height)/25))
            self.surface.blit(self.font.render(self.text, False, self.text_color), (self.rect[0]+(self.rect[2]-(self.text_size*len(self.text))/1.6), self.rect[1]+(self.rect[3]-self.text_size)/2))
            
    def update(self):
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)

    def get_clicked(self):
        if pygame.mouse.get_pressed()[0] and self.mouse_over() and self.enabled:
            if not self.being_clicked:
                self.being_clicked = True
                self.rect = pygame.Rect(self.x+min(self.width, self.height)/20, self.y+min(self.width, self.height)/20, self.width-min(self.width, self.height)/10, self.height-min(self.width, self.height)/10)
                self.text_size = int(self.width/len(self.text)*1.2)
                self.font = pygame.font.SysFont('Times New Roman', self.text_size)
                return False
        else:
            if self.being_clicked == True:
                self.being_clicked = False
                return self.mouse_over()
            self.update()
            self.text_size = int(self.width/len(self.text)*1.5)
            self.font = pygame.font.SysFont('Times New Roman', self.text_size)
            return False


    def mouse_over(self):
        x, y = pygame.mouse.get_pos()
        if x >= self.x and x <= self.x+self.width and self.enabled:
            return y >= self.y and y <= self.y+self.height
        return False

class image_button:
    pass
